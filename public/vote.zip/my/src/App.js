import "./App.css";
import Top from "./components/page-top";
import Main from "./components/vote-pad";

function App() {
  return (
    <div>
      <Top />
      <Main />
    </div>
  );
}

export default App;
